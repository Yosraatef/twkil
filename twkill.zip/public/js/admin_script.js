$(document).ready(function(){
  $('#currentPass').keyup(function(){
      var currentPass = $('#currentPass').val();
    //  alert(currentPass);
      $.ajax({
        type: "post",
        url: '/admin/checkAdminPass',
        data:{currentPass:currentPass},
        success:function(resp){
          if(resp=="false"){
            $("#chekkCurrentPass").html("<font color=red>Current Password Is Incorrect</font>");
          }else if(resp=="true"){
            $("#chekkCurrentPass").html("<font color=green>Current Password Is Correct</font>");
          }

        },error:function(){
          alert('error');
        }
      });
  });
  $('.updateSectionStatus').click(function(){
      var status = $(this).text();
      var section_id = $(this).attr("section_id");
      //alert(status);
      //alert(section_id);
      $.ajax({
        type: "post",
        url: '/admin/updateSectionStatus',
        data:{status:status,section_id:section_id},
        success:function(resp){
          alert('resp');
          if(resp['status']==0){
            $("#section-"+section_id).html("<a class='updateSectionStatus' href='javascript:void(0)''>{{trans('admin.inactive')}}</a>");
          }else if(resp['status']==1){
              $("#section-"+section_id).html("<a class='updateSectionStatus' href='javascript:void(0)''>{{trans('admin.active')}}</a>");
          }
        },error:function(){
          alert('error');
        }
      });
  });

  $('.updateCategoryStatus').click(function(){
      var status = $(this).text();
      var category_id = $(this).attr("category_id");
      //alert(status);
      //alert(section_id);
      $.ajax({
        type: "post",
        url: '/admin/updateCategoryStatus',
        data:{status:status,category_id:category_id},
        success:function(resp){
          // alert('resp');
          if(resp['status']==0){
            $("#category-"+category_id).html("<a class='updateCategoryStatus' href='javascript:void(0)'>	غير مفعل</a>");
          }else if(resp['status']==1){
              $("#category-"+category_id).html("<a class='updateCategoryStatus' href='javascript:void(0)'>مفعل</a>");
          }
        },error:function(){
          alert('error');
        }
      });
  });
});

$(document).ready(function(){
$(".allowAgency").change(function(){
if($(this).val()== 1)
{
  $("#noHours").show();
}
else
{
  $("#noHours").hide();
}
});
});
