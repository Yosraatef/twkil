<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAgency extends Model
{
    //
}
