<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agency extends Model
{
  protected $fillable = [
      'mowkel_id', 'mtawkel_id', 'center_id','is_acceptMtawkel','is_acceptManger','is_acceptMidani','replay'
  ];
}
